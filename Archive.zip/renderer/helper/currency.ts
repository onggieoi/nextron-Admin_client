export const VND = (money: number) => money.toLocaleString('it-IT', { style: 'currency', currency: 'VND' });
