export const typePrintFirst = 'print first';
export const typeNewOrder = 'new order';
export const typeOrderGroup = 'group';
export const typeOrderSingle = 'single';
